document.addEventListener('DOMContentLoaded', () => {
    // Elementos do DOM
    const playerScreen = document.getElementById('player-screen');
    const difficultyScreen = document.getElementById('difficulty-screen');
    const gameScreen = document.getElementById('game-screen');
    const winScreen = document.getElementById('win-screen');
    const playerNameInput = document.getElementById('player-name');
    const startGameBtn = document.getElementById('start-game');
    const difficultyBtns = document.querySelectorAll('[data-difficulty]');
    const gameBoard = document.getElementById('game-board');
    const currentPlayerSpan = document.getElementById('current-player');
    const scoreSpan = document.getElementById('score');
    const pairsFoundSpan = document.getElementById('pairs-found');
    const totalPairsSpan = document.getElementById('total-pairs');
    const winnerNameSpan = document.getElementById('winner-name');
    const finalScoreSpan = document.getElementById('final-score');
    const highScoresList = document.getElementById('high-scores-list');
    const playAgainBtn = document.getElementById('play-again');

    // Variáveis do jogo
    let playerName = '';
    let difficulty = '';
    let cards = [];
    let flippedCards = [];
    let matchedPairs = 0;
    let score = 0;
    let totalPairs = 0;
    let canFlip = true;

    // Emojis para as cartas (poderia ser substituído por imagens de uma API)
    const emojis = ['🐶', '🐱', '🐭', '🐹', '🐰', '🦊', '🐻', '🐼', '🐨', '🐯', 
                   '🦁', '🐮', '🐷', '🐸', '🐵', '🐔', '🐧', '🐦', '🐤', '🦄', 
                   '🐝', '🐛', '🦋', '🐌', '🐞', '🐜', '🦟', '🦗', '🕷', '🦂'];

    // Inicializar eventos
    startGameBtn.addEventListener('click', startGame);
    difficultyBtns.forEach(btn => btn.addEventListener('click', selectDifficulty));
    playAgainBtn.addEventListener('click', resetGame);

    // Função para começar o jogo
    function startGame() {
        playerName = playerNameInput.value.trim();
        
        if (!playerName) {
            alert('Por favor, digite seu nome!');
            return;
        }
        
        playerScreen.classList.add('hidden');
        difficultyScreen.classList.remove('hidden');
    }

    // Função para selecionar a dificuldade
    function selectDifficulty(e) {
        difficulty = e.target.dataset.difficulty;
        difficultyScreen.classList.add('hidden');
        gameScreen.classList.remove('hidden');
        
        // Configurar o jogo baseado na dificuldade
        setupGame();
    }

    // Função para configurar o jogo
    function setupGame() {
        // Limpar tabuleiro
        gameBoard.innerHTML = '';
        flippedCards = [];
        matchedPairs = 0;
        score = 0;
        canFlip = true;
        
        // Configurar baseado na dificuldade
        let rows, cols;
        switch(difficulty) {
            case 'easy':
                rows = 4;
                cols = 4;
                gameBoard.className = 'easy-board';
                break;
            case 'medium':
                rows = 6;
                cols = 6;
                gameBoard.className = 'medium-board';
                break;
            case 'hard':
                rows = 8;
                cols = 8;
                gameBoard.className = 'hard-board';
                break;
        }
        
        totalPairs = (rows * cols) / 2;
        totalPairsSpan.textContent = totalPairs;
        pairsFoundSpan.textContent = matchedPairs;
        scoreSpan.textContent = score;
        currentPlayerSpan.textContent = playerName;
        
        // Criar pares de cartas
        const selectedEmojis = emojis.slice(0, totalPairs);
        cards = [...selectedEmojis, ...selectedEmojis];
        
        // Embaralhar cartas
        shuffleArray(cards);
        
        // Criar elementos das cartas
        cards.forEach((emoji, index) => {
            const card = createCard(emoji, index);
            gameBoard.appendChild(card);
        });
    }

    // Função para criar uma carta
    function createCard(emoji, index) {
        const card = document.createElement('div');
        card.className = 'card';
        card.dataset.index = index;
        card.dataset.value = emoji;
        
        const front = document.createElement('div');
        front.className = 'front';
        front.textContent = emoji;
        
        const back = document.createElement('div');
        back.className = 'back';
        
        card.appendChild(front);
        card.appendChild(back);
        
        card.addEventListener('click', flipCard);
        
        return card;
    }

    // Função para virar carta
    function flipCard() {
        if (!canFlip) return;
        if (flippedCards.length >= 2) return;
        if (this.classList.contains('flipped')) return;
        if (this.classList.contains('matched')) return;
        
        this.classList.add('flipped');
        flippedCards.push(this);
        
        if (flippedCards.length === 2) {
            canFlip = false;
            checkMatch();
        }
    }

    // Função para verificar se as cartas são iguais
    function checkMatch() {
        const [card1, card2] = flippedCards;
        
        if (card1.dataset.value === card2.dataset.value) {
            // Par encontrado
            card1.classList.add('matched');
            card2.classList.add('matched');
            matchedPairs++;
            pairsFoundSpan.textContent = matchedPairs;
            
            // Adicionar pontos
            score += 5;
            scoreSpan.textContent = score;
            
            flippedCards = [];
            canFlip = true;
            
            // Verificar se o jogo acabou
            if (matchedPairs === totalPairs) {
                endGame();
            }
        } else {
            // Não é par
            setTimeout(() => {
                card1.classList.remove('flipped');
                card2.classList.remove('flipped');
                flippedCards = [];
                canFlip = true;
                
                // Remover pontos
                score = Math.max(0, score - 3);
                scoreSpan.textContent = score;
            }, 1000);
        }
    }

    // Função para terminar o jogo
    function endGame() {
        gameScreen.classList.add('hidden');
        winScreen.classList.remove('hidden');
        
        winnerNameSpan.textContent = playerName;
        finalScoreSpan.textContent = score;
        
        // Salvar pontuação
        saveScore(playerName, score);
        
        // Mostrar melhores pontuações
        displayHighScores();
    }

    // Função para reiniciar o jogo
    function resetGame() {
        winScreen.classList.add('hidden');
        playerScreen.classList.remove('hidden');
        playerNameInput.value = '';
    }

    // Função para embaralhar array
    function shuffleArray(array) {
        for (let i = array.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [array[i], array[j]] = [array[j], array[i]];
        }
    }

    // Função para salvar pontuação no localStorage
    function saveScore(name, score) {
        const scores = JSON.parse(localStorage.getItem('memoryGameScores')) || [];
        scores.push({ name, score });
        
        // Ordenar por pontuação (maior primeiro)
        scores.sort((a, b) => b.score - a.score);
        
        // Manter apenas as top 5
        const topScores = scores.slice(0, 5);
        
        localStorage.setItem('memoryGameScores', JSON.stringify(topScores));
    }

    // Função para mostrar as melhores pontuações
    function displayHighScores() {
        const scores = JSON.parse(localStorage.getItem('memoryGameScores')) || [];
        highScoresList.innerHTML = '';
        
        scores.forEach((entry, index) => {
            const li = document.createElement('li');
            li.textContent = `${index + 1}. ${entry.name}: ${entry.score} pontos`;
            highScoresList.appendChild(li);
        });
    }
});